#IMPORTING
from flask import Flask, render_template, request

#INTERACTION
web= Flask(__name__) #create a constructor 

#MAPPING
@web.route('/')
@web.route('/register')  #the link will work for both Url's but not for anyother 

#INPUTS
def homepage():
    return render_template('register.html') #name of the html file to be imported

#MAPPING
@web.route("/confirmation", methods=["POST","GET"])  #tu run thios new file html has been created 
#INPUTS
def register():
    if request.method=="POST":
        n= request.form.get("name")
        p= request.form.get("phone")
        c= request.form.get("city")
        return render_template('confirm.html', name=n, city=c, phone_number=p)
#MAIN
if __name__ == "__main__" :
    web.run(debug=True)