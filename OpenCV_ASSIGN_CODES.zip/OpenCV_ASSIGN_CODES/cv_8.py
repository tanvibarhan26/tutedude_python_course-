import cv2
import numpy as np

img = cv2.imread('/Users/tanvibarhanpurkar/Desktop/airport_image.jpg')

shift_x = 150
shift_y = 70

column = img.shape[1]
row = img.shape[0]

s = np.float32([[1, 0, shift_x], [0, 1, shift_y]])

#Expand the output canvas size
new_column = column + shift_x
new_row = row + shift_y

shifted = cv2.warpAffine(img, s, (new_column, new_row))

cv2.imshow('Original Image', img)
cv2.imshow('Shifted Image', shifted)

cv2.waitKey(0)
cv2.destroyAllWindows()