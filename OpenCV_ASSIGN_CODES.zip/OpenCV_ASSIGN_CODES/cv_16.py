#writing a video
import cv2

cap = cv2.VideoCapture(0, cv2.CAP_AVFOUNDATION)

while True:

    ret, frame = cap.read()

    if not ret:
        print("Cannot access camera")
        break

    cv2.imshow("Live", frame)

    if cv2.waitKey(0) & 0xFF == ord('z'):
        break

cap.release()
cv2.destroyAllWindows()