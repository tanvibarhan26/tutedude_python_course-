#how to read a image
import cv2

img= cv2.imread('/Users/tanvibarhanpurkar/Desktop/airport_image.jpg',0) #used to read the image
cv2.imshow('window',img)
cv2.imwrite('plane.jpg',img)
#to save the image with the changed file name on our system
#cv2.imwrite('/Users/tanvibarhanpurkar/Desktop/plane.jpg',img)
cv2.waitKey(1000)
cv2.destroyAllWindows()
cv2.waitKey(0)  # image will not close automatically
cv2.destroyAllWindows() #only this window should run whenever it is run, others should not.