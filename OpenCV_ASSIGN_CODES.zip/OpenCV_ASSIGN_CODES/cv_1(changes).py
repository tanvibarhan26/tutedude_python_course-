#how to read a image
import cv2

img= cv2.imread('/Users/tanvibarhanpurkar/Desktop/airport_image.jpg',0) #0= black and white
cv2.imshow('window',img)
cv2.waitKey(1000)  # image will not close automatically
cv2.destroyAllWindows() #only this window should run whenever it is run, others should not.