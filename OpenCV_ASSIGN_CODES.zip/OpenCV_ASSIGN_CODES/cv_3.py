#how to resize the image

import cv2

img = cv2.imread('/Users/tanvibarhanpurkar/Desktop/airport_image.jpg', 0)

print("Dimensions of the image: ", img.shape)

width = img.shape[1]  #400              #400
height = 400          #img.shape[1]     #400n
dim = (width, height)
resized = cv2.resize(img, dim)

cv2.imshow("window", resized)

cv2.waitKey(0)

cv2.destroyAllWindows()