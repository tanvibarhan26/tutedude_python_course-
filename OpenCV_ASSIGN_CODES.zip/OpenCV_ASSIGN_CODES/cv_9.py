import cv2

img = cv2.imread('/Users/tanvibarhanpurkar/Desktop/airport_image.jpg')

row = img.shape[0]     # Original Height
column = img.shape[1]  # Original Width

center = (column / 2, row / 2)
angle = 90

r = cv2.getRotationMatrix2D(center, angle, 1)

r[0, 2] += (row - column) / 2
r[1, 2] += (column - row) / 2

rotate = cv2.warpAffine(img, r, (row, column))

cv2.imshow('Rotated', rotate)
cv2.waitKey(0)
cv2.destroyAllWindows()